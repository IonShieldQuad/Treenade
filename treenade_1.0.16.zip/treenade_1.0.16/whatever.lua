script.on_event(defines.events.on_trigger_created_entity, function(event)
    local tree_seed_planting_result = prototypes.item["tree-seed"].plant_result

    if event.entity.name == "tree-seed-dummy" then
        local entity = event.entity
        entity.surface.create_entity {
            name = tree_seed_planting_result,
            position = entity.position,
            force = "neutral" }
        entity.destroy()
    end
end)


local allowed_tiles = data.raw["plant"]["tree-plant"].autoplace["tile_restriction"]
local all_tiles = data.raw["tile"]

local allowed_tiles_lookup = {}
for _, name in ipairs(allowed_tiles) do
    allowed_tiles_lookup[name] = true
end

storage.treenade_allowed_tiles = allowed_tiles_lookup





setup_allowed_tiles = function()
    local allowed_tiles = prototypes.entity["tree-plant"].autoplace["tile_restriction"]

    local allowed_tiles_lookup = {}
    for _, name in ipairs(allowed_tiles) do
        allowed_tiles_lookup[name] = true
    end

    storage.treenade_allowed_tiles = allowed_tiles_lookup
end

script.on_init(setup_allowed_tiles)
script.on_configuration_changed(setup_allowed_tiles)
