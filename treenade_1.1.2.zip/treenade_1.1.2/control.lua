
script.on_event(defines.events.on_trigger_created_entity, function(event)
    
    local nuketile = prototypes.tile["nuclear-ground"]
    if event.entity.name == "tree-plant-dummy" then
        entity = event.entity
        if (entity.valid) then
            local tile = entity.surface.get_tile(entity.position.x, entity.position.y)
            if (not tile.name == "nuclear-ground") then
                entity.surface.create_entity {
                name = prototypes.item["tree-seed"].plant_result,
                position = entity.position,
                force = "neutral"
            }
            end
        end
        entity.destroy()
    end
end)
